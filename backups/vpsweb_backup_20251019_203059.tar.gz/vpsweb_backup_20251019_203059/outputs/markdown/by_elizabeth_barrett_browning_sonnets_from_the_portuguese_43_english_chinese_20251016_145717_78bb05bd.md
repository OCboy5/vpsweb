# Poetry Translation: English → Chinese

---

## 📖 Original Poem

**Language:** English

```
Sonnets From The Portuguese 43
by Elizabeth Barrett Browning

How do I love thee? Let me count the ways.
I love thee to the depth and breadth and height
My soul can reach, when feeling out of sight
For the ends of being and ideal grace.
I love thee to the level of every day’s
Most quiet need, by sun and candle-light.
I love thee freely, as men strive for right.
I love thee purely, as they turn from praise.
I love thee with the passion put to use
In my old griefs, and with my childhood’s faith.
I love thee with a love I seemed to lose
With my lost saints. I love thee with the breath,
Smiles, tears, of all my life; and, if God choose,
I shall but love thee better after death.
```

## 🎭 Final Translation

**Language:** Chinese

```

《葡萄牙十四行诗43》
伊丽莎白·芭蕾特·勃朗宁

我如何爱你？让我细数分明。  
我爱你，至灵魂所能企及的深度、广度与高度，  
当它在无形中探求存在的终极，  
与理想的恩典相契。  
我爱你，如每日最静谧的需要，  
在日光与烛火之下，从晨至夜。  
我自由地爱你，如人们为正义而奋斗；  
我纯净地爱你，如人们回避赞颂。  
我爱你，以昔日悲痛中燃烧的激情，  
也以童年般的信仰。  
我爱你，以那仿佛随逝去圣徒  
而失落的爱。我爱你，以我一生的  
呼吸、微笑与泪水；若神允准，  
我死后将更爱你深沉。
```