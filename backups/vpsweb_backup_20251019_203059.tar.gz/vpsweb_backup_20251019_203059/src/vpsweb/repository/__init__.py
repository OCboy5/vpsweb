"""
VPSWeb Repository Module v0.3.1

Data layer for poetry translation repository.
Provides models, database operations, and VPSWeb integration.
"""

__version__ = "0.3.1"
__author__ = "VPSWeb Development Team"
