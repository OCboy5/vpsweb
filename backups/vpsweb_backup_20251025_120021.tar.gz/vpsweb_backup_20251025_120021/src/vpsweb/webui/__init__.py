"""
VPSWeb Web UI Module v0.3.1

Web interface layer for poetry translation repository.
Provides FastAPI application, templates, and API endpoints.
"""

__version__ = "0.3.1"
__author__ = "VPSWeb Development Team"
