# Poetry Translation: English → Chinese

---

## 📖 Original Poem

**Language:** English

```
Sonnets From The Portuguese 43
by Elizabeth Barrett Browning

How do I love thee? Let me count the ways.
I love thee to the depth and breadth and height
My soul can reach, when feeling out of sight
For the ends of being and ideal grace.
I love thee to the level of every day’s
Most quiet need, by sun and candle-light.
I love thee freely, as men strive for right.
I love thee purely, as they turn from praise.
I love thee with the passion put to use
In my old griefs, and with my childhood’s faith.
I love thee with a love I seemed to lose
With my lost saints. I love thee with the breath,
Smiles, tears, of all my life; and, if God choose,
I shall but love thee better after death.
```

## 🎭 Final Translation

**Language:** Chinese

```

我如何爱你？让我细数方式。  
我爱你，至灵魂所能触及的  
深度、广度与高度，当它摸索向  
存在的尽头与理想的恩慈。  
我爱你，如每日最静默的所需，  
在日光下与烛光中。  
我爱你，自由地，如人们追求正义；  
我爱你，纯粹地，如人们远离赞颂。  
我爱你，带着从旧日悲痛中汲取的激情，  
也带着童年那般笃信的热忱。  
我爱你，用我仿佛随失落的圣徒们失去的爱；  
我爱你，以呼吸、微笑与泪水，贯穿我一生；  
若上帝允准，  
我只会更爱你，死后。
```