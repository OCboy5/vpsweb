# Poetry Translation: Chinese → English

---

## 📖 Original Poem

**Language:** Chinese

```
諸人共遊周家墓柏下
作者： 陶渊明

今日天氣佳，清吹與鳴彈。
感彼柏下人，安得不為歡！
清歌散新聲，綠酒開芳顏。
未知明日事，余襟良已殫。
```

## 🎭 Final Translation

**Language:** English

```

Gathering with Friends beneath the Zhou Family Tomb Cypresses  
by Tao Yuanming  

Today the weather's fine—clear flutes, resounding strings,  
Moved by the souls beneath these cypresses, how can we not rejoice?  
Pure songs scatter fresh strains, green wine reveals blooming faces,  
Not knowing what tomorrow holds—my heart is quietly drained.
```