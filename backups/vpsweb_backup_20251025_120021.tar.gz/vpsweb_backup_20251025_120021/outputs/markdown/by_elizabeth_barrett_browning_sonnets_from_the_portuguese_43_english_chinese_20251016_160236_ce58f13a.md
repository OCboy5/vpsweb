# Poetry Translation: English → Chinese

---

## 📖 Original Poem

**Language:** English

```
Sonnets From The Portuguese 43
by Elizabeth Barrett Browning

How do I love thee? Let me count the ways.
I love thee to the depth and breadth and height
My soul can reach, when feeling out of sight
For the ends of being and ideal grace.
I love thee to the level of every day’s
Most quiet need, by sun and candle-light.
I love thee freely, as men strive for right.
I love thee purely, as they turn from praise.
I love thee with the passion put to use
In my old griefs, and with my childhood’s faith.
I love thee with a love I seemed to lose
With my lost saints. I love thee with the breath,
Smiles, tears, of all my life; and, if God choose,
I shall but love thee better after death.
```

## 🎭 Final Translation

**Language:** Chinese

```

《葡萄牙十四行诗43》
伊丽莎白·巴雷特·布朗宁

我如何爱你？容我细数端详：
我灵魂所能触及的深度、广度与高度，
便是我爱你的尺度——当在无形中摸索
存在的边界与至善之美。
我爱你，如每日最静谧的需要，
在阳光下，在烛光里。
我自由地爱你，如人们为正义奋起；
我纯洁地爱你，如面对赞美时的转身。
我以往昔悲伤中转化的热忱爱你，
也以儿时那般虔诚的信仰。
我爱你，用那份似乎随失落圣徒
一同遗失的挚爱。我爱你，
用我一生的呼吸、微笑与泪滴；
若蒙神恩，死后我唯能更爱你。
```